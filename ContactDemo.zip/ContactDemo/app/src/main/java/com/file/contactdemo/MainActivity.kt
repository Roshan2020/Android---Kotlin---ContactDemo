package com.file.contactdemo

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.file.contactdemo.adapter.ContactAdapter
import com.file.contactdemo.databinding.ActivityMainBinding
import com.file.contactdemo.listener.ContactListener
import com.file.contactdemo.model.ContactModel

class MainActivity : AppCompatActivity(), ContactListener {
    var binding: ActivityMainBinding? = null
    var contacts: ArrayList<ContactModel>? = ArrayList()
    var adapter: ContactAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        adapter = ContactAdapter(this, this)
        binding!!.contacts.adapter = adapter

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_CONTACTS), 20)
        } else{
            getContacts()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        getContacts()
    }

    override fun onClickContact(number: String) {
        var uri = Uri.parse("tel:" +  number)
        var intent = Intent(Intent.ACTION_DIAL, uri)
        startActivity(intent)

    }

    fun getContacts(){
        var curser = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)

        if (curser!!.moveToFirst()){
            do {
                var name = curser.getString(curser.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                var number = curser.getString(curser.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                contacts!!.add(ContactModel(name, number))
            } while (curser.moveToNext())
            adapter!!.update(contacts!!)
        }
    }
}