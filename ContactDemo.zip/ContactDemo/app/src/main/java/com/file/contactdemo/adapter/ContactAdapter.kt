package com.file.contactdemo.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.file.contactdemo.databinding.ItemContactBinding
import com.file.contactdemo.listener.ContactListener
import com.file.contactdemo.model.ContactModel

class ContactAdapter(var context: Context, var listener: ContactListener) :  RecyclerView.Adapter<ContactAdapter.ContactViewHolder>(){
    var binding: ItemContactBinding? = null
    var contacts: ArrayList<ContactModel>? = ArrayList()

    inner class ContactViewHolder(itemView: ItemContactBinding): ViewHolder(itemView.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        var inflater = LayoutInflater.from(parent.context)
        binding = ItemContactBinding.inflate(inflater, parent, false)
        return ContactViewHolder(binding!!)
    }

    override fun getItemCount(): Int {
        return contacts!!.size
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        binding!!.tvName.text = contacts!![position].name
        binding!!.tvNumber.text = contacts!![position].number

        holder.itemView.setOnClickListener{
            listener.onClickContact(contacts!![position].number!!)
        }
    }

    fun update(list: ArrayList<ContactModel>){
        contacts = list
        notifyDataSetChanged()
    }
}