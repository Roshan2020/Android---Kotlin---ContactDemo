package com.file.contactdemo.listener

interface ContactListener {
    fun onClickContact(number: String)
}