package com.file.contactdemo.model

data class ContactModel(
    var name: String? = "",
    var number: String? = ""
)
